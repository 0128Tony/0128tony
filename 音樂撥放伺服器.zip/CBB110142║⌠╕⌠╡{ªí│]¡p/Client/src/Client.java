import java.io.*;
import java.net.*;
import java.util.Scanner;
import javazoom.jl.player.Player;

public class Client {

    static int bytesTransferred = 0;
    static int transferC=0;
   
    public static void main(String[] args) throws Exception{

        // 1. Connect to server
        Socket clientSocket = new Socket("localhost", 1234);
        System.out.println("已連線至音樂伺服器(IP:Port): " + clientSocket.getRemoteSocketAddress());

        // 2. Start chatting
        BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        PrintWriter outToServer = new PrintWriter(clientSocket.getOutputStream(), true);
        

        try (Scanner scanner = new Scanner(System.in)) {
            String message = inFromServer.readLine();
            String filename;
            String message2 = message;
            
            
            
            do {
                System.out.print("請輸入play(顯示歌單): ");
                message = scanner.nextLine();
                  if (message.equals("play")){    
                  System.out.print("\r\n");
                  System.out.print(message2 + "\n");
                  }
                  else {
                    // Send error message to client and ask for input again
                    outToServer.println("error command");
                    System.out.print("Error command. 請重新輸入正確指令(play): ");
                    while (true) {
                        message = scanner.nextLine();
                        if (message.equals("play")) {
                            break;
                        }
                        outToServer.println("error command");
                        System.out.print("Error command. 請重新輸入正確指令(play): ");
                    }
                    if (message.equals("play")){

                        System.out.print("\r\n");
                        System.out.print(message2 + "\n");

                    }
                }
                 System.out.print("選擇您要的歌曲 (1-3): ");
                 message = scanner.nextLine();
                
                if (message.equals("1")) {
                    outToServer.println(message);

                    InputStream inputStream = clientSocket.getInputStream();
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        
                        byteArrayOutputStream.write(buffer, 0, bytesRead);
                        if(bytesRead==1024){
                        System.out.println("正在接收資料 ... " + bytesRead + " bytes");
                        transferC++;
                    }
                        else if(bytesRead<=1024)
                        {

                            System.out.println("正在接收資料 ... " + bytesRead + "  bytes");
                            System.out.println("資料接收完成");
                            System.out.print("\r\n");
                        }
                       
                        
                        bytesTransferred += bytesRead;
                }
                    byteArrayOutputStream.flush();
                    
                    System.out.println("正在連線至伺服器 ... ");
                    System.out.print("\r\n");
                    filename="歌曲播放中: 1.Tuesday - Burak Yeter ...";
                    System.out.print(filename);


                    // Play music
                    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
                    Player player = new Player(byteArrayInputStream);
                    player.play();
                    
                    // Finish playing music
                    System.out.print("\r\n");
                    System.out.println("音樂播放完畢...用戶端離線");
                    message="exit";

            }
                else if (message.equals("2")) {
                    outToServer.println(message);
                    
                    InputStream inputStream = clientSocket.getInputStream();
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        
                        byteArrayOutputStream.write(buffer, 0, bytesRead);
                        if(bytesRead==1024){
                        System.out.println("正在接收資料 ... " + bytesRead + " bytes");
                        transferC++;
                    }
                        else if(bytesRead<=1024)
                        {

                            System.out.println("正在接收資料 ... " + bytesRead + "  bytes");
                            System.out.println("資料接收完成");
                            System.out.print("\r\n");
                        }
                       
                        
                        bytesTransferred += bytesRead;
                }
                    byteArrayOutputStream.flush();
                    
                    System.out.println("正在連線至伺服器 ... ");
                    System.out.print("\r\n");
                    filename="歌曲播放中: 2.SAINt JHN - Roses ...";
                    System.out.print(filename);


                    // Play music
                    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
                    Player player = new Player(byteArrayInputStream);
                    player.play();

                    // Finish playing music
                    System.out.print("\r\n");
                    System.out.println("音樂播放完畢...用戶端離線");
                    message="exit";

               // } 
            }
                else if (message.equals("3")) {
                    outToServer.println(message);
                    
                    InputStream inputStream = clientSocket.getInputStream();
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        
                        byteArrayOutputStream.write(buffer, 0, bytesRead);
                        if(bytesRead==1024){
                        System.out.println("正在接收資料 ... " + bytesRead + " bytes");
                        transferC++;
                    }
                        else if(bytesRead<=1024)
                        {

                            System.out.println("正在接收資料 ... " + bytesRead + "  bytes");
                            System.out.println("資料接收完成");
                            System.out.print("\r\n");
                        }
                       
                        
                        bytesTransferred += bytesRead;
                }
                    byteArrayOutputStream.flush();
                    
                    System.out.println("正在連線至伺服器 ... ");
                    System.out.print("\r\n");
                    filename="歌曲播放中: 3.OneRepublic - Counting Stars ...";
                    System.out.print(filename);


                    // Play music
                    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
                    Player player = new Player(byteArrayInputStream);
                    player.play();

                    // Finish playing music
                    System.out.print("\r\n");
                    System.out.println("音樂播放完畢...用戶端離線");
                    message="exit";

            }
                else if (message.equals("exit")) {
                    outToServer.println(message);
                } else {
                    // Send error message to client and ask for input again
                    outToServer.println("error command");
                    System.out.print("Error command. 請重新輸入正確的歌曲編號: ");
                    while (true) {
                        message = scanner.nextLine();
                        if (message.equals("1") ||message.equals("2")|| message.equals("3")||message.equals("exit")) {
                            break;
                        }
                        outToServer.println("error command");
                        System.out.print("Error command. 請重新輸入正確的歌曲編號: ");
                    }
                    if (message.equals("1") ||message.equals("2")|| message.equals("3")) {
                        outToServer.println(message);
                        String message3;
                        message3=message;

                        InputStream inputStream = clientSocket.getInputStream();
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        byte[] buffer = new byte[1024];
                        int bytesRead;
                        while ((bytesRead = inputStream.read(buffer)) != -1) {
                            
                            byteArrayOutputStream.write(buffer, 0, bytesRead);
                            if(bytesRead==1024){
                            System.out.println("正在接收資料 ... " + bytesRead + " bytes");
                            transferC++;
                        }
                            else if(bytesRead<=1024)
                            {
   
                                System.out.println("正在接收資料 ... " + bytesRead + "  bytes");
                                System.out.println("資料接收完成");
                                System.out.print("\r\n");
                            }
                           
                            bytesTransferred += bytesRead;
                    }
                        byteArrayOutputStream.flush();
                        
                        System.out.println("正在連線至伺服器 ... ");
                        System.out.print("\r\n");
                        if (message3.equals("1")){
                            filename="歌曲播放中: 1.Tuesday - Burak Yeter ...";
                            System.out.print(filename);
                        }
                        else if (message3.equals("2")){
                            filename="歌曲播放中: 2.srcSAINt JHN - Roses ...";
                            System.out.print(filename);
                        }
        
                        else if (message3.equals("3")){
                            filename="歌曲播放中: 3.OneRepublic - Counting Stars ...";
                            System.out.print(filename);
                            
                        }
   
   
                        // Play music
                        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
                        Player player = new Player(byteArrayInputStream);
                        player.play();
   
                        // Finish playing music
                        System.out.print("\r\n");
                        System.out.println("音樂播放完畢...用戶端離線");
                        message="exit";

                    } else {
                        outToServer.println(message);
                    }
                }

                // Receive and print server message
                String serverMessage = inFromServer.readLine();
                if (serverMessage != null) {
                    System.out.println(serverMessage);
                }

            
        } while (!message.equals("exit"));
    }
        //3. Close the connection
        inFromServer.close();
        outToServer.close();
        clientSocket.close();
    }
}
