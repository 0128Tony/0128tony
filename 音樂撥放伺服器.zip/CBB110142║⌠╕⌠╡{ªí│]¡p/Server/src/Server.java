import java.io.*;
import java.net.*;

public class Server {
    
    public static void main(String[] args) throws Exception {
        try (ServerSocket serverSocket = new ServerSocket(1234)) {
            System.out.println("音樂伺服器已啟動位於(port): " + serverSocket.getLocalPort());
            while (true) {
            try{
                Socket clientSocket = serverSocket.accept();
                System.out.println("用戶端已連線至伺服器(IP:Port): " + clientSocket.getRemoteSocketAddress());

                // 開始對話
                BufferedReader inFromClient = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                OutputStream outToClient = clientSocket.getOutputStream();
                outToClient.write("請選擇歌曲:1.Tuesday - Burak Yeter.mp3, 2.SAINt JHN - Roses.mp3, 3.OneRepublic - Counting Stars.mp3\n".getBytes());

                String command = inFromClient.readLine();
                System.out.println("Received command: " + command);
                
                while (!command.equals("1") && !command.equals("2")&& !command.equals("3")&& !command.equals("exit")) {
                    //傳送錯誤訊息給用戶端，並顯示接收到的訊息。
                    outToClient.write("Error command! Please enter 'play' or 'exit'.".getBytes());
                    outToClient.flush();
                    command = inFromClient.readLine();
                    System.out.println("Received command: " + command);
                }

                if (command.equals("1")) {
                        // 播放音樂
                        outToClient.write("正再播放: 1.Tuesday - Burak Yeter ...".getBytes());
                        outToClient.flush();
                        
                        //將檔案以 buffer size=1024, 依序的傳送到 client
                        FileInputStream fileInputStream = new FileInputStream("src\\Tuesday - Burak Yeter ft. Danelle Sandoval (slow reverb).mp3");
                        byte[] buffer = new byte[1024];
                        int bytesRead = 0;
                        int bytesTransferred = 0;
                        int transferCount=0;
                            
                            while ((bytesRead = fileInputStream.read(buffer)) != -1) {    
                                if (bytesRead == 1024) {
                                System.out.println("正在傳輸資料至客戶端 ... ");
                                System.out.println("資料傳遞中 ... " + bytesRead + " bytes.");
                                System.out.print("\r\n");
                                transferCount++; // Increment transfer count
                            }
                            outToClient.write(buffer, 0, bytesRead);
                            bytesTransferred += bytesRead;
                        }
                            outToClient.flush();
                            fileInputStream.close();

                            //輸出最後一筆不滿1024的資料傳輸狀態。
                            System.out.println("正在傳輸資料至客戶端 ... ");
                            System.out.println("資料傳遞中 ... " + (bytesTransferred-(transferCount)*1024) + " bytes。" );
                            System.out.print("\r\n");

                            //如果傳輸完成，輸出總共傳輸大小。
                            System.out.println("傳遞完成。資料大小: " + bytesTransferred + " byte。" );
                            System.out.println("資料傳遞共: " + (transferCount+1) + " 筆" );
                    }

                else if (command.equals("2")) {
                        // 播放音樂
                        outToClient.write("正再播放: 2.SAINt JHN - Roses ...".getBytes());
                        outToClient.flush();
                    
                        FileInputStream fileInputStream = new FileInputStream("src\\SAINt JHN - Roses (Imanbek Remix) (Official Music Video).mp3");
                        byte[] buffer = new byte[1024];
                        int bytesRead = 0;
                        int bytesTransferred = 0;
                        int transferCount=0;
    
                            while ((bytesRead = fileInputStream.read(buffer)) != -1) {    
                                if (bytesRead == 1024) {
                                    System.out.println("正在傳輸資料至客戶端 ... ");
                                    System.out.println("資料傳遞中 ... " + bytesRead + " bytes.");
                                    System.out.print("\r\n");
                                    transferCount++; // Increment transfer count
                                }
                                outToClient.write(buffer, 0, bytesRead);
                                bytesTransferred += bytesRead;
                            }
                            outToClient.flush();
                            fileInputStream.close();
    
                            //輸出最後一筆不滿1024的資料傳輸狀態。
                            System.out.println("正在傳輸資料至客戶端 ... ");
                            System.out.println("資料傳遞中 ... " + (bytesTransferred-(transferCount)*1024) + " bytes。" );
                            System.out.print("\r\n");
    
                            //如果傳輸完成，輸出總共傳輸大小。
                            System.out.println("傳遞完成。資料大小: " + bytesTransferred + " byte。" );
                            System.out.println("資料傳遞共: " + (transferCount+1) + " 筆" );
                        }
                     else if (command.equals("3")) {
                           // 播放音樂
                            outToClient.write("正再播放: 3.OneRepublic - Counting Stars ...".getBytes());
                             outToClient.flush();
        
                            FileInputStream fileInputStream = new FileInputStream("src\\OneRepublic - Counting Stars.mp3");
                            byte[] buffer = new byte[1024];
                            int bytesRead = 0;
                            int bytesTransferred = 0;
                            int transferCount=0;
        
                                while ((bytesRead = fileInputStream.read(buffer)) != -1) {    
                                    if (bytesRead == 1024) {
                                        System.out.println("正在傳輸資料至客戶端 ... ");
                                        System.out.println("資料傳遞中 ... " + bytesRead + " bytes.");
                                        System.out.print("\r\n");
                                        transferCount++; 
                                    }
                                    outToClient.write(buffer, 0, bytesRead);
                                    bytesTransferred += bytesRead;
                                }
                                outToClient.flush();
                                fileInputStream.close();
        
                                //輸出最後一筆不滿1024的資料傳輸狀態。
                                System.out.println("正在傳輸資料至客戶端 ... ");
                                System.out.println("資料傳遞中 ... " + (bytesTransferred-(transferCount)*1024) + " bytes。" );
                                System.out.print("\r\n");
        
                                //如果傳輸完成，輸出總共傳輸大小。
                                System.out.println("傳遞完成。資料大小: " + bytesTransferred + " byte。" );
                                System.out.println("資料傳遞共: " + (transferCount+1) + " 筆" );
                            }

                    // Close connection
                    inFromClient.close();
                    outToClient.close();
                    clientSocket.close();
                }catch (IOException e) {
                    System.out.print("\r\n");
                    System.out.println("Warning!用戶端非正常離線!");
                }

                
            }
        }
    }
}